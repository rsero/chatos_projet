package fr.upem.net.tcp.nonblocking.data;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;

public class PrivateConnexionTransmission implements Data  {

	private final ByteBuffer bbin;
	private final SelectionKey key;

	public PrivateConnexionTransmission(ByteBuffer bbin, SelectionKey key) {
		this.bbin = bbin;
		this.key=key;
	}

	public ByteBuffer encode(){
		System.out.println(" encode privateconnexiontransmission : "+bbin);
		return bbin;
	}

	@Override
	public void accept(DataVisitor visitor) throws IOException { visitor.visit(this); }

	public SelectionKey getKey(){
		return key;
	}

	public ByteBuffer get(){
		return bbin;
	}

}
