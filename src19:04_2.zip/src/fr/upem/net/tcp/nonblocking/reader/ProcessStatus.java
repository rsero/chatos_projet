package fr.upem.net.tcp.nonblocking.reader;

public enum ProcessStatus {
	DONE,REFILL,ERROR
}
