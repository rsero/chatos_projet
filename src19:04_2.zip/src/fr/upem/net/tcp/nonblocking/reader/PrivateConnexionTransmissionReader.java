package fr.upem.net.tcp.nonblocking.reader;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.charset.StandardCharsets;

import fr.upem.net.tcp.nonblocking.data.PrivateConnexionTransmission;

public class PrivateConnexionTransmissionReader implements Reader<PrivateConnexionTransmission>{

    public PrivateConnexionTransmissionReader(SelectionKey key) {
        this.key=key;
    }

    private enum State {
        DONE, WAITING, ERROR
    }

    private static int BUFFER_SIZE = 1024;
    private State state = State.WAITING;
    private ByteBuffer internalbb = ByteBuffer.allocate(BUFFER_SIZE); // write-mode
    private final SelectionKey key;
    private PrivateConnexionTransmission value;

    @Override
    public ProcessStatus process(ByteBuffer bb, SelectionKey key) {
        if (state == State.DONE || state == State.ERROR) {
            throw new IllegalStateException();
        }
        if(bb.position() == 0){
            return ProcessStatus.REFILL;
        }
        bb.flip();
        try {
            System.out.println("bb remaining : "+ bb.remaining());
            System.out.println("internalbb remaining : "+ internalbb.remaining());
            if (bb.remaining() <= internalbb.remaining()) {
                internalbb.put(bb);
            } else {
                var oldLimit = bb.limit();
                bb.limit(internalbb.remaining());
                internalbb.put(bb);
                bb.limit(oldLimit);
            }
        } finally {
            bb.compact();
        }
        state = State.DONE;
        internalbb.flip();
        System.out.println("internalbb "+ internalbb);
        value = new PrivateConnexionTransmission(internalbb, key);
        bb.clear();
        return ProcessStatus.DONE;
    }

    @Override
    public PrivateConnexionTransmission get() throws IOException {
        if (state != State.DONE) {
            throw new IllegalStateException();
        }
        var utf = StandardCharsets.UTF_8;
        System.out.println("get data "+ utf.decode(value.get()));
        return value;
    }

    @Override
    public void reset() {
        state = State.WAITING;
        internalbb.clear();
    }

}
